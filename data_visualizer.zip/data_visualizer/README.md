ECOR1042 Group Project T-125
April 9th 2023
Data Visualizer version 1.0
Contact: Nick Fuda nickfuda@cmail.carleton.ca

Description: 
This software reads the provided .csv file containing information about students and can be used to manage, sort, and visualize the data.
When loading data, it can filter data by 'School', 'Age, 'Failures' and 'Health', or 'All' to load all data in the file.* Loaded data can be sorted by 'Age', 'StudyTime', 'Failures', and 'G_Avg'.
Loaded data can be analyzed using curve-fitting to compare the G_Avg with any of the headers in the .csv file except 'School', and generates the equation of the curve with the desired order.
Loaded data can also be visualized by generating a histogram of the number of students within the entered attribute.

*Note that loading by a filter removes that filter from the data, and that filter cannot be used in subsequent commands.

Dependencies:
Python 3.11.1
numpy 1.24.2
matplotlib 3.7.1
Wing101 or other Python IDE (optional, only use if you wish to run the code through the IDE and not through Python directly)

Installation:
Extract the zip file to a folder of your choice. Ensure all files are present in the same directory.
Ensure the file named 'student-test.csv' is in the same directory that you extracted the zip file to. 
	-If using another file, the file of choice must be in .csv format, in the following order: [School, Age, Health, Failures, Absences, G1, G2, G3]
Install Python 3.11.1 (from https://www.python.org/), Wing 101 IDE (optional, from https://wingware.com/downloads/wing-101 or another Python IDE)
Install module dependencies using the Terminal in MacOS, Command Prompt in Windows 
Numpy ->		python -m pip install numpy
Matplotlib -> 	python -m pip install matplotlib
Open text_ui.py with python, or use the IDE to open and run the program module.**
For larger tasks, consider using batch UI (refer to the video on Brightspace)

**Sometimes when opening text_ui directly with python, the program may close unexpectedly after entering the filter attribute
in the load command. This tends to happen on the first-time run, and running the program again will usually solve this issue.


Usage: Refer to the video uploaded to the Brightspace page.

Credits:
Anirudh Kandula -
files: student_failures_list.py, test2.py, sort_students_failures_bubble.py, sort.py, curve_fit.py
functions: student_failures_list, test_return_list_correct_lenght, sort_students_failures_bubble, sort, curve_fit

Patrick Spalton - 
files: student_health_list.py, load_data.py, test4.py, test_load_data.py, sort_students_g_avg_inserton.py, sort.py, histogram.py
functions: student_health_list, add_average, test_add_average, test_load_data, sort_students_g_avg_insertion, sort, histogram

Neo Ling - 
files: student_age_list.py, test3.py, sort_students_time_selection.py
functions: student_age_list, test_correct_dict_inside_list, sort_students_time_selection

Nick Fuda - 
files: student_school_list.py, load_data.py, test1.py, test_load_data.py, sort_students_age_bubble.py, sort.py, text_UI.py, batch_UI.py, data visualization demo video
functions: student_school_list, load_data, test_return_list, sort_students_age_bubble, sort, batch_UI, text_UI

MIT License

Copyright (c) 2023 T-125 ECOR 1042

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.